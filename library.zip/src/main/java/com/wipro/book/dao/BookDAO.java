package com.wipro.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.wipro.book.bean.BookBean;
import com.wipro.book.util.DBUtil;
public class BookDAO {
    public int createBook(BookBean bookBean) {
        Connection con = DBUtil.getDBConnection();
        String query = "INSERT INTO BOOK_TBL VALUES (?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, bookBean.getIsbn());
            ps.setString(2, bookBean.getBookName());
            ps.setString(3, String.valueOf(bookBean.getBookType()));
            ps.setInt(4, bookBean.getAuthor().getAuthorCode());
            ps.setDouble(5, bookBean.getCost());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                return 1;  
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return 0;
    }
    public BookBean fetchBookByISBN(String isbn) {
        Connection con = DBUtil.getDBConnection();
        String query = "SELECT * FROM BOOK_TBL WHERE UPPER(ISBN) = ?";
        try {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, isbn.trim().toUpperCase());   
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                BookBean bookBean = new BookBean();
                bookBean.setIsbn(rs.getString("ISBN"));
                bookBean.setBookName(rs.getString("BOOK_TITLE"));
                bookBean.setBookType(rs.getString("BOOK_TYPE").charAt(0));
                bookBean.setCost(rs.getFloat("BOOK_COST"));
                bookBean.setAuthor(
                    new AuthorDAO().getAuthor(rs.getInt("AUTHOR_CODE"))
                );
                return bookBean;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }}
