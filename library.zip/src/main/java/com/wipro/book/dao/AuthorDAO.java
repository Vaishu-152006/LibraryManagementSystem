package com.wipro.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.wipro.book.bean.AuthorBean;
import com.wipro.book.util.DBUtil;

public class AuthorDAO {
    public AuthorBean getAuthor(int authorCode) {
        AuthorBean author = null;
        try {
            Connection con = DBUtil.getDBConnection();
            String query = "SELECT * FROM AUTHOR_TBL WHERE AUTHOR_CODE = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, authorCode);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                author = new AuthorBean();
                author.setAuthorCode(rs.getInt(1));
                author.setAuthorName(rs.getString(2));
                author.setContactNo(rs.getLong(3));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return author;
    }
    public AuthorBean getAuthor(String authorName) {
        AuthorBean author = null;
        Connection con = DBUtil.getDBConnection();
        String query = "SELECT * FROM AUTHOR_TBL WHERE AUTHOR_NAME = ?";
        try {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, authorName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                author = new AuthorBean();
                author.setAuthorCode(rs.getInt(1));
                author.setAuthorName(rs.getString(2));
                author.setContactNo(rs.getLong(3));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return author;   
    }
}